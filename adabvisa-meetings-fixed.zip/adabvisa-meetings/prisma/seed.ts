/**
 * داده‌های اولیه سیستم - واحدها، سمت‌ها و کاربران نمونه
 * اجرا: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import { Role } from "../src/lib/enums";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("در حال ایجاد داده‌های نمونه...");

  const passwordHash = await bcrypt.hash("Admin@12345", 10);

  // ---------------- واحدها ----------------
  const management = await prisma.unit.upsert({
    where: { code: "م" },
    update: {},
    create: { name: "مدیریت داخلی", code: "م", colorHex: "#1f2c4d" }
  });

  const marketing = await prisma.unit.upsert({
    where: { code: "الف" },
    update: {},
    create: { name: "واحد مارکتینگ", code: "الف", colorHex: "#8654c9" }
  });

  const sales = await prisma.unit.upsert({
    where: { code: "ب" },
    update: {},
    create: { name: "واحد فروش", code: "ب", colorHex: "#2f9e6e" }
  });

  const finance = await prisma.unit.upsert({
    where: { code: "ج" },
    update: {},
    create: { name: "واحد مالی", code: "ج", colorHex: "#c07a2b" }
  });

  const hr = await prisma.unit.upsert({
    where: { code: "د" },
    update: {},
    create: { name: "منابع انسانی", code: "د", colorHex: "#c94f8f" }
  });

  const it = await prisma.unit.upsert({
    where: { code: "ه" },
    update: {},
    create: { name: "فناوری اطلاعات", code: "ه", colorHex: "#2f8bc9" }
  });

  // ---------------- سمت‌ها و دسترسی‌ها ----------------
  // این سمت‌ها دقیقا سناریوی درخواستی را پیاده می‌کنند:
  // - هر کارمند فقط تسک‌های خودش را می‌بیند
  // - مدیرکل/مدیرعامل/قائم‌مقام/مدیر منابع انسانی: کل سازمان (شامل مدیریت پرسنل/واحدها/سمت‌ها)
  // - مدیر هر واحد: تسک‌های سرپرست‌های همان واحد را هم می‌بیند
  const posSuperAdmin = await prisma.position.upsert({
    where: { title: "مدیرکل" },
    update: {},
    create: {
      title: "مدیرکل",
      baseRole: Role.SUPER_ADMIN,
      canManageOrgWide: true,
      canViewAllOrg: true,
      canViewUnitStaff: true,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posCEO = await prisma.position.upsert({
    where: { title: "مدیرعامل" },
    update: {},
    create: {
      title: "مدیرعامل",
      baseRole: Role.CEO,
      canManageOrgWide: true,
      canViewAllOrg: true,
      canViewUnitStaff: true,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posDeputy = await prisma.position.upsert({
    where: { title: "قائم مقام" },
    update: {},
    create: {
      title: "قائم مقام",
      baseRole: Role.DEPUTY,
      canManageOrgWide: false,
      canViewAllOrg: true,
      canViewUnitStaff: true,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posHrManager = await prisma.position.upsert({
    where: { title: "مدیر منابع انسانی" },
    update: {},
    create: {
      title: "مدیر منابع انسانی",
      baseRole: Role.UNIT_MANAGER,
      canManageOrgWide: false,
      canViewAllOrg: true,
      canViewUnitStaff: true,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posUnitManager = await prisma.position.upsert({
    where: { title: "مدیر واحد" },
    update: {},
    create: {
      title: "مدیر واحد",
      baseRole: Role.UNIT_MANAGER,
      canManageOrgWide: false,
      canViewAllOrg: false,
      canViewUnitStaff: true, // می‌تواند تسک‌های سرپرست‌های همان واحد را ببیند
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posSupervisor = await prisma.position.upsert({
    where: { title: "سرپرست" },
    update: {},
    create: {
      title: "سرپرست",
      baseRole: Role.SUPERVISOR,
      canManageOrgWide: false,
      canViewAllOrg: false,
      canViewUnitStaff: false,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: true
    }
  });

  const posStaff = await prisma.position.upsert({
    where: { title: "کارشناس" },
    update: {},
    create: {
      title: "کارشناس",
      baseRole: Role.STAFF,
      canManageOrgWide: false,
      canViewAllOrg: false,
      canViewUnitStaff: false,
      canCreateMeeting: true,
      canCreateMinute: true,
      canExportExcel: false
    }
  });

  // ---------------- کاربران ----------------
  const usersData = [
    { fullName: "مدیرکل سامانه", phone: "09120000001", role: Role.SUPER_ADMIN, unitId: management.id, positionId: posSuperAdmin.id, positionTitle: "مدیرکل" },
    { fullName: "مدیرعامل", phone: "09120000002", role: Role.CEO, unitId: management.id, positionId: posCEO.id, positionTitle: "مدیرعامل" },
    { fullName: "قائم مقام", phone: "09120000003", role: Role.DEPUTY, unitId: management.id, positionId: posDeputy.id, positionTitle: "قائم مقام مدیرعامل" },
    { fullName: "مدیر واحد مارکتینگ", phone: "09120000004", role: Role.UNIT_MANAGER, unitId: marketing.id, positionId: posUnitManager.id, positionTitle: "مدیر مارکتینگ" },
    { fullName: "سرپرست مارکتینگ", phone: "09120000005", role: Role.SUPERVISOR, unitId: marketing.id, positionId: posSupervisor.id, positionTitle: "سرپرست تیم محتوا" },
    { fullName: "کارشناس مارکتینگ", phone: "09120000006", role: Role.STAFF, unitId: marketing.id, positionId: posStaff.id, positionTitle: "کارشناس مارکتینگ" },
    { fullName: "مدیر واحد فروش", phone: "09120000007", role: Role.UNIT_MANAGER, unitId: sales.id, positionId: posUnitManager.id, positionTitle: "مدیر فروش" },
    { fullName: "کارشناس فروش", phone: "09120000008", role: Role.STAFF, unitId: sales.id, positionId: posStaff.id, positionTitle: "کارشناس فروش" },
    { fullName: "مدیر مالی", phone: "09120000009", role: Role.UNIT_MANAGER, unitId: finance.id, positionId: posUnitManager.id, positionTitle: "مدیر مالی" },
    { fullName: "مدیر منابع انسانی", phone: "09120000010", role: Role.UNIT_MANAGER, unitId: hr.id, positionId: posHrManager.id, positionTitle: "مدیر منابع انسانی" },
    { fullName: "کارشناس فناوری اطلاعات", phone: "09120000011", role: Role.STAFF, unitId: it.id, positionId: posStaff.id, positionTitle: "کارشناس IT" }
  ];

  for (const u of usersData) {
    await prisma.user.upsert({
      where: { phone: u.phone },
      update: {},
      create: { ...u, passwordHash }
    });
  }

  console.log("داده‌های نمونه با موفقیت ایجاد شدند.");
  console.log("---------------------------------------------");
  console.log("ورود آزمایشی با هر یک از شماره‌های بالا، رمز عبور: Admin@12345");
  console.log("---------------------------------------------");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
