import type { Config } from "tailwindcss";

// پالت رنگی برند ادب‌ویزا: سرمه‌ای تیره به‌عنوان رنگ اصلی + رنگ‌های مکمل برای واحد/وضعیت‌های مختلف
const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/modules/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      fontFamily: {
        vazir: ["var(--font-vazir)", "Tahoma", "sans-serif"]
      },
      colors: {
        // رنگ اصلی برند - سرمه‌ای تیره
        navy: {
          50: "#eef1f7",
          100: "#d7deec",
          200: "#b0bdd9",
          300: "#8899c1",
          400: "#5c6fa0",
          500: "#3d4f80",
          600: "#2a3a63",
          700: "#1f2c4d",
          800: "#141d38",
          900: "#0c1226",
          950: "#070b19"
        },
        // طلایی - رنگ تاکیدی برند
        gold: {
          50: "#fbf6e9",
          100: "#f5e8bf",
          200: "#eed690",
          300: "#e5c15c",
          400: "#d8ab35",
          500: "#c1911f",
          600: "#9c7318",
          700: "#785616",
          800: "#563d13",
          900: "#372710"
        },
        // رنگ‌های وضعیت (قرمز/زرد/سبز - مطابق فرم پایش)
        status: {
          danger: "#d64545",
          warning: "#e0a72e",
          success: "#3f9e5e",
          info: "#3574c4",
          neutral: "#8a94a6"
        },
        // رنگ‌های مکمل برای واحدهای مختلف سازمانی
        unit: {
          marketing: "#8654c9",
          sales: "#2f9e6e",
          finance: "#c07a2b",
          hr: "#c94f8f",
          it: "#2f8bc9",
          management: "#1f2c4d"
        },
        surface: {
          DEFAULT: "#f5f7fb",
          card: "#ffffff",
          muted: "#eef1f7"
        }
      },
      borderRadius: {
        xl: "0.9rem",
        "2xl": "1.25rem"
      },
      boxShadow: {
        card: "0 2px 14px 0 rgba(20, 29, 56, 0.06)",
        soft: "0 1px 3px 0 rgba(20, 29, 56, 0.08)"
      }
    }
  },
  plugins: []
};

export default config;
