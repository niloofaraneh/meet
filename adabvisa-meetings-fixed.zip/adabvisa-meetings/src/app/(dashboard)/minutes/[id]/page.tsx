import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { notFound } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { formatJalaliDate } from "@/lib/jalali";
import { TASK_STATUS_LABELS, TASK_STATUS_COLORS, PRIORITY_LABELS } from "@/lib/constants";
import { AddTaskForm } from "@/components/tasks/AddTaskForm";
import { ExportButton } from "@/components/minutes/ExportButton";
import { TaskComments } from "@/components/tasks/TaskComments";
import { canExportExcel } from "@/lib/permissions";

export default async function MinuteDetailPage({ params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return null;

  const minute = await db.meetingMinute.findUnique({
    where: { id: params.id },
    include: {
      meeting: true,
      recorder: true,
      tasks: {
        include: {
          assignees: { include: { user: true } },
          assigner: true,
          comments: { include: { author: true }, orderBy: { createdAt: "asc" } }
        },
        orderBy: { createdAt: "asc" }
      }
    }
  });

  if (!minute) notFound();

  const users = await db.user.findMany({ where: { isActive: true }, orderBy: { fullName: "asc" } });

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold text-navy-800">صورتجلسه {minute.number}</h1>
          <p className="text-sm text-navy-400 mt-1">{minute.meeting.title} — {formatJalaliDate(minute.meeting.date)}</p>
        </div>
        {canExportExcel(user) && <ExportButton />}
      </div>

      {minute.summary && (
        <Card>
          <h2 className="text-sm font-bold text-navy-800 mb-2">خلاصه مذاکرات</h2>
          <p className="text-sm text-navy-600 whitespace-pre-line">{minute.summary}</p>
        </Card>
      )}

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-navy-800">مصوبات و تسک‌های این صورتجلسه</h2>
          <Badge color="#3574c4">{minute.tasks.length} مورد</Badge>
        </div>

        {minute.tasks.length === 0 && (
          <p className="text-sm text-navy-300 text-center py-6">هنوز مصوبه‌ای برای این صورتجلسه ثبت نشده است</p>
        )}

        <div className="space-y-3">
          {minute.tasks.map((t, idx) => {
            const isResponsible = t.assignees.some((a) => a.userId === user.id);
            return (
              <div key={t.id} className="border border-navy-50 rounded-xl p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs text-navy-300 mb-0.5">ردیف {idx + 1}</p>
                    <p className="text-sm text-navy-800 font-medium">{t.title}</p>
                    {t.explanation && <p className="text-xs text-navy-400 mt-0.5">{t.explanation}</p>}
                    <p className="text-xs text-navy-500 mt-1.5">
                      مسئولین: {t.assignees.map((a) => a.user.fullName).join("، ")}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-1.5 shrink-0">
                    <Badge color={TASK_STATUS_COLORS[t.status]}>{TASK_STATUS_LABELS[t.status]}</Badge>
                    <span className="text-xs text-navy-400">{PRIORITY_LABELS[t.priority]}</span>
                    <span className="text-xs text-navy-400">مهلت: {formatJalaliDate(t.dueDate)}</span>
                  </div>
                </div>
                <TaskComments
                  taskId={t.id}
                  comments={t.comments.map((c) => ({
                    id: c.id,
                    body: c.body,
                    createdAt: c.createdAt.toISOString(),
                    author: { id: c.author.id, fullName: c.author.fullName, avatarUrl: c.author.avatarUrl }
                  }))}
                />
              </div>
            );
          })}
        </div>
      </Card>

      <Card>
        <h2 className="text-sm font-bold text-navy-800 mb-4">افزودن مصوبه/تسک جدید</h2>
        <AddTaskForm
          minuteId={minute.id}
          users={users.map((u) => ({ id: u.id, fullName: u.fullName }))}
        />
      </Card>
    </div>
  );
}
