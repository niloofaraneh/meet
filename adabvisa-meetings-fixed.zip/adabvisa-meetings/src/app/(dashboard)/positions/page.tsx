import { db } from "@/lib/db";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";
import { Card } from "@/components/ui/Card";
import { NewPositionForm } from "@/components/positions/NewPositionForm";
import { PositionsList } from "@/components/positions/PositionsList";

export default async function PositionsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!canManageOrgStructure(user)) redirect("/dashboard");

  const positions = await db.position.findMany({
    include: { _count: { select: { users: true } } },
    orderBy: { title: "asc" }
  });

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-navy-800">سمت‌ها و سطوح دسترسی</h1>
        <p className="text-sm text-navy-400 mt-1">تعریف سمت‌های سازمانی دلخواه (سرپرست، مدیر، کارشناس و ...) به همراه سطح دسترسی هرکدام</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <h2 className="text-sm font-bold text-navy-800 mb-3">سمت‌های تعریف‌شده</h2>
          <PositionsList positions={positions} />
        </Card>
        <Card>
          <h2 className="text-sm font-bold text-navy-800 mb-3">افزودن سمت جدید</h2>
          <NewPositionForm />
        </Card>
      </div>
    </div>
  );
}
