import { getUnitTree } from "@/modules/units/unit.service";
import { Card } from "@/components/ui/Card";
import { NewUnitForm } from "@/components/units/NewUnitForm";
import { UnitNode } from "@/components/units/UnitNode";

export default async function UnitsPage() {
  const tree = await getUnitTree();

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-navy-800">واحدهای سازمانی</h1>
        <p className="text-sm text-navy-400 mt-1">تعریف واحدها و سلسله‌مراتب بین آن‌ها؛ هر واحد یک کد اختصاصی برای شماره‌گذاری صورتجلسات دارد</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <h2 className="text-sm font-bold text-navy-800 mb-3">ساختار واحدها</h2>
          <div className="space-y-1">
            {tree.map((u: any) => <UnitNode key={u.id} unit={u} />)}
          </div>
        </Card>
        <Card>
          <h2 className="text-sm font-bold text-navy-800 mb-3">افزودن واحد جدید</h2>
          <NewUnitForm parentOptions={tree} />
        </Card>
      </div>
    </div>
  );
}
