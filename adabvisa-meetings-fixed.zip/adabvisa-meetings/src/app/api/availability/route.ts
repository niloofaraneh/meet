import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { checkAttendeesAvailability } from "@/modules/meetings/availability.service";
import { parseJalaliString } from "@/lib/jalali";
import { z } from "zod";

const schema = z.object({
  userIds: z.array(z.string()).min(1),
  jalaliDate: z.string(),
  startTime: z.string(), // HH:MM
  endTime: z.string()
});

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const [sh, sm] = parsed.data.startTime.split(":").map(Number);
  const [eh, em] = parsed.data.endTime.split(":").map(Number);
  const start = parseJalaliString(parsed.data.jalaliDate, sh, sm);
  const end = parseJalaliString(parsed.data.jalaliDate, eh, em);

  if (!start || !end) {
    return NextResponse.json({ success: false, error: "تاریخ شمسی نامعتبر است" }, { status: 400 });
  }

  const result = await checkAttendeesAvailability(parsed.data.userIds, start, end);

  return NextResponse.json({ success: true, data: result });
}
