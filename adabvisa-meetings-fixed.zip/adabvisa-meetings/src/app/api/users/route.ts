import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";
import { normalizePhone } from "@/lib/utils";
import bcrypt from "bcryptjs";
import { z } from "zod";

const schema = z.object({
  fullName: z.string().min(2),
  phone: z.string().min(10),
  email: z.string().email().optional().or(z.literal("")),
  password: z.string().min(6),
  role: z.enum(["SUPER_ADMIN", "CEO", "DEPUTY", "UNIT_MANAGER", "SUPERVISOR", "STAFF"]),
  unitId: z.string().optional(),
  positionId: z.string().optional(),
  positionTitle: z.string().optional()
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const users = await db.user.findMany({
    include: { unit: true },
    orderBy: { fullName: "asc" }
  });

  // اطلاعات حساس ارسال نمی‌شود
  const safe = users.map(({ passwordHash, ...rest }) => rest);
  return NextResponse.json({ success: true, data: safe });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const passwordHash = await bcrypt.hash(parsed.data.password, 10);
  const created = await db.user.create({
    data: {
      fullName: parsed.data.fullName,
      phone: normalizePhone(parsed.data.phone),
      email: parsed.data.email || undefined,
      passwordHash,
      role: parsed.data.role,
      unitId: parsed.data.unitId || undefined,
      positionId: parsed.data.positionId || undefined,
      positionTitle: parsed.data.positionTitle
    }
  });

  const { passwordHash: _, ...safe } = created;
  return NextResponse.json({ success: true, data: safe });
}
