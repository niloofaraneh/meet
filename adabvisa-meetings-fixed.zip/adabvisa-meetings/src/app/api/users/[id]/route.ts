import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";
import { normalizePhone } from "@/lib/utils";
import bcrypt from "bcryptjs";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const profile = await db.user.findUnique({
    where: { id: params.id },
    include: {
      unit: true,
      positionRef: true,
      taskAssignments: { include: { task: { include: { minute: { include: { meeting: true } } } } } },
      createdMeetings: true
    }
  });

  if (!profile) return NextResponse.json({ success: false, error: "کاربر یافت نشد" }, { status: 404 });
  const { passwordHash, ...safe } = profile;
  return NextResponse.json({ success: true, data: safe });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const isSelf = user.id === params.id;
  const isOrgAdmin = canManageOrgStructure(user);

  if (!isSelf && !isOrgAdmin) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const data: Record<string, unknown> = {};

  // فیلدهایی که خود شخص هم می‌تواند روی پروفایل خودش تغییر دهد
  const selfAllowed = ["fullName", "avatarUrl", "bio", "notifyByInApp", "notifyBySms"];
  for (const key of selfAllowed) if (key in body) data[key] = body[key];

  // فیلدهایی که فقط مدیر با دسترسی مدیریت کل سازمان می‌تواند تغییر دهد
  if (isOrgAdmin) {
    if ("fullName" in body) data.fullName = body.fullName;
    if ("email" in body) data.email = body.email || null;
    if ("phone" in body) data.phone = normalizePhone(body.phone);
    if ("positionTitle" in body) data.positionTitle = body.positionTitle;
    if ("positionId" in body) data.positionId = body.positionId || null;
    if ("unitId" in body) data.unitId = body.unitId || null;
    if ("role" in body) data.role = body.role;
    if ("isActive" in body) data.isActive = !!body.isActive;
    if (body.password) data.passwordHash = await bcrypt.hash(body.password, 10);
  }

  const updated = await db.user.update({ where: { id: params.id }, data });
  const { passwordHash, ...safe } = updated;
  return NextResponse.json({ success: true, data: safe });
}

// حذف پرسنل: به‌صورت پیش‌فرض فقط غیرفعال می‌شود (چون ممکن است تسک/جلسه‌ی مرتبط داشته باشد)؛
// اگر هیچ رکورد وابسته‌ای نداشته باشد (مثلا به‌اشتباه اضافه شده)، حذف کامل هم انجام می‌شود.
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }
  if (user.id === params.id) {
    return NextResponse.json({ success: false, error: "امکان حذف حساب خودتان وجود ندارد" }, { status: 400 });
  }

  const [meetingCount, taskCount, minuteCount] = await Promise.all([
    db.meeting.count({ where: { OR: [{ creatorId: params.id }, { attendees: { some: { userId: params.id } } }] } }),
    db.taskAssignee.count({ where: { userId: params.id } }),
    db.meetingMinute.count({ where: { recorderId: params.id } })
  ]);

  const hasHistory = meetingCount > 0 || taskCount > 0 || minuteCount > 0;

  if (!hasHistory) {
    await db.user.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true, data: { mode: "hard_delete" } });
  }

  await db.user.update({ where: { id: params.id }, data: { isActive: false } });
  return NextResponse.json({ success: true, data: { mode: "deactivated" } });
}
