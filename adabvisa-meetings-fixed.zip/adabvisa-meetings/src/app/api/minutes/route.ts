import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { createMeetingMinute } from "@/modules/minutes/minute.service";
import { z } from "zod";

const schema = z.object({
  meetingId: z.string(),
  unitId: z.string(),
  summary: z.string().optional(),
  attachmentUrl: z.string().optional()
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const minutes = await db.meetingMinute.findMany({
    include: { meeting: true, recorder: true, tasks: { include: { assignees: { include: { user: true } } } } },
    orderBy: { createdAt: "desc" }
  });

  return NextResponse.json({ success: true, data: minutes });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const minute = await createMeetingMinute({
    meetingId: parsed.data.meetingId,
    unitId: parsed.data.unitId,
    recorderId: user.id,
    summary: parsed.data.summary,
    attachmentUrl: parsed.data.attachmentUrl
  });

  return NextResponse.json({ success: true, data: minute });
}
