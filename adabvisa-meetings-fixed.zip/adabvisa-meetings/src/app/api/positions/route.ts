import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";
import { z } from "zod";

const schema = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  baseRole: z.enum(["SUPER_ADMIN", "CEO", "DEPUTY", "UNIT_MANAGER", "SUPERVISOR", "STAFF"]).default("STAFF"),
  canManageOrgWide: z.boolean().default(false),
  canViewAllOrg: z.boolean().default(false),
  canViewUnitStaff: z.boolean().default(false),
  canCreateMeeting: z.boolean().default(true),
  canCreateMinute: z.boolean().default(true),
  canExportExcel: z.boolean().default(true)
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const positions = await db.position.findMany({
    include: { _count: { select: { users: true } } },
    orderBy: { title: "asc" }
  });
  return NextResponse.json({ success: true, data: positions });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const position = await db.position.create({ data: parsed.data });
  return NextResponse.json({ success: true, data: position });
}
