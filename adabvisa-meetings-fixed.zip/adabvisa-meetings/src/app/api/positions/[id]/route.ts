import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const allowed = [
    "title",
    "description",
    "baseRole",
    "canManageOrgWide",
    "canViewAllOrg",
    "canViewUnitStaff",
    "canCreateMeeting",
    "canCreateMinute",
    "canExportExcel",
    "isActive"
  ];
  const data: Record<string, unknown> = {};
  for (const key of allowed) if (key in body) data[key] = body[key];

  const updated = await db.position.update({ where: { id: params.id }, data });
  return NextResponse.json({ success: true, data: updated });
}

// حذف سمت: اگر کسی با این سمت وجود دارد، اجازه‌ی حذف داده نمی‌شود (باید ابتدا سمت افراد را تغییر دهید)
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const usersCount = await db.user.count({ where: { positionId: params.id } });
  if (usersCount > 0) {
    return NextResponse.json(
      { success: false, error: `این سمت به ${usersCount} نفر اختصاص دارد؛ ابتدا سمت آن‌ها را تغییر دهید.` },
      { status: 400 }
    );
  }

  await db.position.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true });
}
