import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { getUnitTree } from "@/modules/units/unit.service";
import { canManageOrgStructure } from "@/lib/permissions";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2),
  code: z.string().min(1).max(3),
  colorHex: z.string().optional(),
  parentId: z.string().optional(),
  description: z.string().optional()
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const tree = await getUnitTree();
  return NextResponse.json({ success: true, data: tree });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  const unit = await db.unit.create({ data: parsed.data });
  return NextResponse.json({ success: true, data: unit });
}
