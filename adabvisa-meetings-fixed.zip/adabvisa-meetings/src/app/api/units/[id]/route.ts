import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { canManageOrgStructure } from "@/lib/permissions";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2).optional(),
  code: z.string().min(1).max(3).optional(),
  colorHex: z.string().optional(),
  parentId: z.string().nullable().optional(),
  description: z.string().optional(),
  isActive: z.boolean().optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });

  if (parsed.data.parentId === params.id) {
    return NextResponse.json({ success: false, error: "یک واحد نمی‌تواند بالادستی خودش باشد" }, { status: 400 });
  }

  const updated = await db.unit.update({ where: { id: params.id }, data: parsed.data });
  return NextResponse.json({ success: true, data: updated });
}

// حذف واحد: اگر پرسنل یا زیرواحدی داشته باشد، به‌جای حذف کامل غیرفعال می‌شود
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });
  if (!canManageOrgStructure(user)) {
    return NextResponse.json({ success: false, error: "دسترسی غیرمجاز" }, { status: 403 });
  }

  const [userCount, childCount] = await Promise.all([
    db.user.count({ where: { unitId: params.id } }),
    db.unit.count({ where: { parentId: params.id } })
  ]);

  if (userCount > 0 || childCount > 0) {
    await db.unit.update({ where: { id: params.id }, data: { isActive: false } });
    return NextResponse.json({ success: true, data: { mode: "deactivated" } });
  }

  await db.unit.delete({ where: { id: params.id } });
  return NextResponse.json({ success: true, data: { mode: "hard_delete" } });
}
