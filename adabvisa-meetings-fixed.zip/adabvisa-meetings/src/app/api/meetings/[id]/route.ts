import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { forceConfirmMeeting, cancelMeeting } from "@/modules/meetings/meeting.service";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const meeting = await db.meeting.findUnique({
    where: { id: params.id },
    include: {
      creator: true,
      attendees: { include: { user: true } },
      minutes: { include: { tasks: { include: { assignees: true } } } }
    }
  });

  if (!meeting) return NextResponse.json({ success: false, error: "جلسه یافت نشد" }, { status: 404 });
  return NextResponse.json({ success: true, data: meeting });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();

  if (body.action === "confirm") {
    const meeting = await forceConfirmMeeting(params.id);
    return NextResponse.json({ success: true, data: meeting });
  }
  if (body.action === "cancel") {
    const meeting = await cancelMeeting(params.id);
    return NextResponse.json({ success: true, data: meeting });
  }

  return NextResponse.json({ success: false, error: "اکشن نامعتبر" }, { status: 400 });
}
