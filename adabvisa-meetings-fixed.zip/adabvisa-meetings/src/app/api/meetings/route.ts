import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/session";
import { createMeetingRequest } from "@/modules/meetings/meeting.service";
import { parseJalaliString } from "@/lib/jalali";
import { z } from "zod";

const createSchema = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  jalaliDate: z.string(),
  startTime: z.string(),
  endTime: z.string(),
  location: z.string().optional(),
  attendeeIds: z.array(z.string()).min(1)
});

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const meetings = await db.meeting.findMany({
    where: {
      OR: [{ creatorId: user.id }, { attendees: { some: { userId: user.id } } }]
    },
    include: {
      creator: true,
      attendees: { include: { user: true } },
      minutes: true
    },
    orderBy: { date: "desc" }
  });

  return NextResponse.json({ success: true, data: meetings });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ success: false, error: parsed.error.message }, { status: 400 });
  }

  const [sh, sm] = parsed.data.startTime.split(":").map(Number);
  const [eh, em] = parsed.data.endTime.split(":").map(Number);
  const date = parseJalaliString(parsed.data.jalaliDate, sh, sm);
  const endDate = parseJalaliString(parsed.data.jalaliDate, eh, em);

  if (!date || !endDate) {
    return NextResponse.json({ success: false, error: "تاریخ شمسی نامعتبر است" }, { status: 400 });
  }

  const meeting = await createMeetingRequest({
    creatorId: user.id,
    title: parsed.data.title,
    description: parsed.data.description,
    date,
    endDate,
    location: parsed.data.location,
    attendeeIds: parsed.data.attendeeIds
  });

  return NextResponse.json({ success: true, data: meeting });
}
