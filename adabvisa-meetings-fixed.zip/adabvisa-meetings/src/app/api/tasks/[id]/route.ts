import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/session";
import { db } from "@/lib/db";
import {
  respondToTaskAssignment,
  approveProposedDueDate,
  markTaskDone,
  setTaskStatus,
  addTaskComment
} from "@/modules/tasks/task.service";
import { MANUAL_TASK_STATUSES, TaskStatus } from "@/lib/enums";

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const task = await db.task.findUnique({
    where: { id: params.id },
    include: {
      assignees: { include: { user: true } },
      assigner: true,
      minute: { include: { meeting: true } },
      comments: { include: { author: true }, orderBy: { createdAt: "asc" } }
    }
  });
  if (!task) return NextResponse.json({ success: false, error: "تسک یافت نشد" }, { status: 404 });
  return NextResponse.json({ success: true, data: task });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ success: false, error: "احراز هویت نشده" }, { status: 401 });

  const body = await req.json();

  if (body.action === "respond") {
    const task = await respondToTaskAssignment({
      taskId: params.id,
      accept: body.accept,
      proposedDueDate: body.proposedDueDate ? new Date(body.proposedDueDate) : undefined,
      note: body.note
    });
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "approveProposed") {
    const task = await approveProposedDueDate(params.id);
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "markDone") {
    const task = await markTaskDone(params.id);
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "setStatus") {
    const status = body.status as TaskStatus;
    if (!MANUAL_TASK_STATUSES.includes(status)) {
      return NextResponse.json({ success: false, error: "وضعیت نامعتبر" }, { status: 400 });
    }
    const task = await setTaskStatus(params.id, status, body.note);
    return NextResponse.json({ success: true, data: task });
  }

  if (body.action === "addComment") {
    if (!body.body || typeof body.body !== "string" || !body.body.trim()) {
      return NextResponse.json({ success: false, error: "متن نظر الزامی است" }, { status: 400 });
    }
    const comment = await addTaskComment({ taskId: params.id, authorId: user.id, body: body.body.trim() });
    return NextResponse.json({ success: true, data: comment });
  }

  return NextResponse.json({ success: false, error: "اکشن نامعتبر" }, { status: 400 });
}
