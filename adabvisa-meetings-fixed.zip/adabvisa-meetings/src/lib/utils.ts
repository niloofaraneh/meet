import { TaskStatus } from "@/lib/enums";

export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(" ");
}

// محاسبه‌ی وضعیت رنگی تسک بر اساس مهلت و اینکه انجام شده یا نه
// سبز: انجام شده | زرد: کمتر از ۳ روز تا مهلت | قرمز: از مهلت گذشته | آبی: در جریان عادی
export function computeTaskStatus(dueDate: Date, doneAt: Date | null): TaskStatus {
  if (doneAt) return "GREEN_DONE";
  const now = new Date();
  const diffDays = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays < 0) return "RED_OVERDUE";
  if (diffDays <= 3) return "YELLOW_DUE_SOON";
  return "IN_PROGRESS";
}

export function initials(fullName: string): string {
  const parts = fullName.trim().split(" ").filter(Boolean);
  if (parts.length === 0) return "؟";
  if (parts.length === 1) return parts[0].slice(0, 2);
  return parts[0][0] + parts[1][0];
}

export function normalizePhone(phone: string): string {
  return phone.trim().replace(/[^\d]/g, "");
}
