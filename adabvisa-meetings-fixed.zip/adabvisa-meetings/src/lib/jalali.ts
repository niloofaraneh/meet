/**
 * ابزارهای تبدیل و نمایش تاریخ شمسی (جلالی)
 * از کتابخانه‌ی سبک jalaali-js استفاده شده که کاملا آفلاین/لوکال است (بدون فراخوانی سرویس بیرونی)
 */
import jalaali from "jalaali-js";

const weekDays = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const monthNames = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
];

export function toJalali(date: Date | string) {
  const d = typeof date === "string" ? new Date(date) : date;
  const j = jalaali.toJalaali(d);
  return { jy: j.jy, jm: j.jm, jd: j.jd };
}

// تاریخ عددی به فرمت ۱۴۰۴/۰۳/۰۱
export function formatJalaliDate(date: Date | string): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  const { jy, jm, jd } = toJalali(d);
  return `${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`;
}

// تاریخ به همراه ساعت: ۱۴۰۴/۰۳/۰۱ - ۱۴:۳۰
export function formatJalaliDateTime(date: Date | string): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  const time = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  return `${formatJalaliDate(d)} - ${time}`;
}

// تاریخ کامل با نام روز هفته و ماه: چهارشنبه ۱ خرداد ۱۴۰۴
export function formatJalaliFull(date: Date | string): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  const { jy, jm, jd } = toJalali(d);
  const weekDay = weekDays[d.getDay()];
  return `${weekDay} ${jd} ${monthNames[jm - 1]} ${jy}`;
}

// تبدیل تاریخ شمسی وارد شده توسط کاربر (رشته yyyy/mm/dd) به آبجکت Date میلادی
export function jalaliToGregorian(jy: number, jm: number, jd: number, hour = 0, minute = 0): Date {
  const g = jalaali.toGregorian(jy, jm, jd);
  return new Date(g.gy, g.gm - 1, g.gd, hour, minute);
}

export function parseJalaliString(value: string, hour = 0, minute = 0): Date | null {
  const parts = value.split("/").map((p) => parseInt(p.trim(), 10));
  if (parts.length !== 3 || parts.some((p) => Number.isNaN(p))) return null;
  const [jy, jm, jd] = parts;
  return jalaliToGregorian(jy, jm, jd, hour, minute);
}

// سال شمسی جاری - برای شماره‌گذاری خودکار صورتجلسات
export function currentJalaliYear(): number {
  return toJalali(new Date()).jy;
}

export function jalaliMonthNames() {
  return monthNames;
}

export function jalaliWeekDays() {
  return weekDays;
}

// فاصله‌ی نسبی فارسی: "۲ روز مانده"، "۳ روز گذشته"، "امروز"
export function relativeDaysFa(dueDate: Date | string): string {
  const d = typeof dueDate === "string" ? new Date(dueDate) : dueDate;
  const now = new Date();
  const diffMs = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() -
    new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const days = Math.round(diffMs / (1000 * 60 * 60 * 24));
  if (days === 0) return "امروز";
  if (days > 0) return `${days} روز مانده تا مهلت`;
  return `${Math.abs(days)} روز از مهلت گذشته`;
}
