import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { db } from "./db";
import { normalizePhone } from "./utils";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login"
  },
  providers: [
    CredentialsProvider({
      name: "ورود با شماره موبایل",
      credentials: {
        phone: { label: "شماره موبایل", type: "text" },
        password: { label: "رمز عبور", type: "password" }
      },
      async authorize(credentials) {
        if (!credentials?.phone || !credentials?.password) return null;

        const phone = normalizePhone(credentials.phone);
        const user = await db.user.findUnique({
          where: { phone },
          include: { unit: true, positionRef: true }
        });

        if (!user || !user.isActive) return null;

        const isValid = await bcrypt.compare(credentials.password, user.passwordHash);
        if (!isValid) return null;

        // اگر سمتی تعریف نشده باشد (کاربر قدیمی)، مدیرکل/مدیرعامل دسترسی کامل و بقیه دسترسی محدود دارند
        const legacyOrgWide = user.role === "SUPER_ADMIN" || user.role === "CEO";
        const legacyViewAll = legacyOrgWide || user.role === "DEPUTY";

        return {
          id: user.id,
          name: user.fullName,
          phone: user.phone,
          role: user.role,
          unitId: user.unitId,
          unitName: user.unit?.name ?? null,
          avatarUrl: user.avatarUrl ?? null,
          positionTitle: user.positionRef?.title ?? user.positionTitle ?? null,
          canManageOrgWide: user.positionRef?.canManageOrgWide ?? legacyOrgWide,
          canViewAllOrg: user.positionRef?.canViewAllOrg ?? legacyViewAll,
          canViewUnitStaff: user.positionRef?.canViewUnitStaff ?? (user.role === "UNIT_MANAGER" || user.role === "SUPERVISOR"),
          canCreateMeeting: user.positionRef?.canCreateMeeting ?? true,
          canCreateMinute: user.positionRef?.canCreateMinute ?? true,
          canExportExcel: user.positionRef?.canExportExcel ?? true
        } as any;
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const u = user as any;
        token.id = u.id;
        token.role = u.role;
        token.unitId = u.unitId;
        token.unitName = u.unitName;
        token.avatarUrl = u.avatarUrl;
        token.phone = u.phone;
        token.positionTitle = u.positionTitle;
        token.canManageOrgWide = u.canManageOrgWide;
        token.canViewAllOrg = u.canViewAllOrg;
        token.canViewUnitStaff = u.canViewUnitStaff;
        token.canCreateMeeting = u.canCreateMeeting;
        token.canCreateMinute = u.canCreateMinute;
        token.canExportExcel = u.canExportExcel;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.id;
        (session.user as any).role = token.role;
        (session.user as any).unitId = token.unitId;
        (session.user as any).unitName = token.unitName;
        (session.user as any).avatarUrl = token.avatarUrl;
        (session.user as any).phone = token.phone;
        (session.user as any).positionTitle = token.positionTitle;
        (session.user as any).canManageOrgWide = token.canManageOrgWide;
        (session.user as any).canViewAllOrg = token.canViewAllOrg;
        (session.user as any).canViewUnitStaff = token.canViewUnitStaff;
        (session.user as any).canCreateMeeting = token.canCreateMeeting;
        (session.user as any).canCreateMinute = token.canCreateMinute;
        (session.user as any).canExportExcel = token.canExportExcel;
      }
      return session;
    }
  },
  secret: process.env.NEXTAUTH_SECRET
};
