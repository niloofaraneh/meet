import { Role } from "@/lib/enums";
import { ROLE_RANK } from "./constants";

// دسترسی‌های واقعی از روی سمت (Position) کاربر خوانده می‌شود.
// این فیلدها داخل session.user قرار می‌گیرند (نگاه کنید به src/lib/auth.ts)
export type SessionUser = {
  id: string;
  fullName: string;
  role: Role;
  unitId: string | null;
  canManageOrgWide?: boolean;
  canViewAllOrg?: boolean;
  canViewUnitStaff?: boolean;
  canCreateMeeting?: boolean;
  canCreateMinute?: boolean;
  canExportExcel?: boolean;
};

// آیا کاربر دسترسی مدیریتی کامل دارد (مدیرکل - سازگاری با نسخه قبل)
export function isSuperAdmin(user: SessionUser) {
  return user.role === "SUPER_ADMIN" || !!user.canManageOrgWide;
}

// دسترسی مدیریت واحدها/پرسنل/سمت‌ها (کل سازمان)
export function canManageOrgStructure(user: SessionUser): boolean {
  return !!user.canManageOrgWide;
}

// آیا کاربر می‌تواند گزارش‌ها و داشبورد کل سازمان (نه فقط واحد خودش) را ببیند
export function canViewOrgWideReports(user: SessionUser): boolean {
  return !!user.canManageOrgWide || !!user.canViewAllOrg;
}

// آیا کاربر می‌تواند تسک‌های زیرمجموعه‌ی مستقیمِ همان واحد را ببیند (مثلا مدیر واحد -> سرپرست‌های واحد خودش)
export function canViewUnitTeam(user: SessionUser): boolean {
  return canViewOrgWideReports(user) || !!user.canViewUnitStaff;
}

export function canCreateMeeting(user: SessionUser): boolean {
  return user.canCreateMeeting !== false;
}

export function canCreateMinute(user: SessionUser): boolean {
  return user.canCreateMinute !== false;
}

export function canExportExcel(user: SessionUser): boolean {
  return user.canExportExcel !== false;
}

export function isHigherOrEqualRank(a: Role, b: Role): boolean {
  return ROLE_RANK[a] <= ROLE_RANK[b];
}
