/**
 * سرویس بررسی تایم‌های خالی/اشغال هر شخص.
 * منطق: هر جلسه‌ای که برای کاربر در وضعیت CONFIRMED یا PENDING_APPROVAL باشد
 * به‌عنوان بازه‌ی اشغال در نظر گرفته می‌شود (چون هنوز رد نشده، احتمال برگزاری هست).
 */
import { db } from "@/lib/db";

export type BusySlot = {
  meetingId: string;
  title: string;
  start: Date;
  end: Date;
  status: string;
};

export async function getUserBusySlots(userId: string, from: Date, to: Date): Promise<BusySlot[]> {
  const attendances = await db.meetingAttendee.findMany({
    where: {
      userId,
      response: { in: ["ACCEPTED", "PENDING"] },
      meeting: {
        status: { in: ["CONFIRMED", "PENDING_APPROVAL"] },
        date: { gte: from, lte: to }
      }
    },
    include: { meeting: true }
  });

  const created = await db.meeting.findMany({
    where: {
      creatorId: userId,
      status: { in: ["CONFIRMED", "PENDING_APPROVAL"] },
      date: { gte: from, lte: to }
    }
  });

  const fromAttendance = attendances.map((a) => ({
    meetingId: a.meeting.id,
    title: a.meeting.title,
    start: a.meeting.date,
    end: a.meeting.endDate,
    status: a.meeting.status
  }));

  const fromCreated = created.map((m) => ({
    meetingId: m.id,
    title: m.title,
    start: m.date,
    end: m.endDate,
    status: m.status
  }));

  const map = new Map<string, BusySlot>();
  [...fromAttendance, ...fromCreated].forEach((s) => map.set(s.meetingId, s));
  return Array.from(map.values()).sort((a, b) => a.start.getTime() - b.start.getTime());
}

// بررسی تداخل زمانی یک بازه‌ی پیشنهادی با بازه‌های اشغال یک یا چند کاربر
export function hasOverlap(start: Date, end: Date, slots: BusySlot[]): BusySlot[] {
  return slots.filter((slot) => start < slot.end && end > slot.start);
}

export async function checkAttendeesAvailability(
  userIds: string[],
  start: Date,
  end: Date
): Promise<Record<string, BusySlot[]>> {
  const result: Record<string, BusySlot[]> = {};
  for (const userId of userIds) {
    const daySlots = await getUserBusySlots(
      userId,
      new Date(start.getFullYear(), start.getMonth(), start.getDate()),
      new Date(start.getFullYear(), start.getMonth(), start.getDate() + 1)
    );
    result[userId] = hasOverlap(start, end, daySlots);
  }
  return result;
}
