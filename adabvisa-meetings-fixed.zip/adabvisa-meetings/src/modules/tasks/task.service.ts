/**
 * سرویس تسک/مصوبات.
 * هر تسک می‌تواند چند مسئول همزمان داشته باشد (TaskAssignee).
 * وقتی یک نفر برای دیگری/دیگران تسک می‌سازد، تسک با approvalStatus=PENDING ساخته می‌شود
 * مگر اینکه فقط خودش را مسئول کرده باشد.
 */
import { db } from "@/lib/db";
import { TaskPriority, TaskStatus, MANUAL_TASK_STATUSES } from "@/lib/enums";
import { notifyUser, notifyManyUsers } from "@/modules/notifications/notification.service";
import { formatJalaliDate } from "@/lib/jalali";
import { computeTaskStatus } from "@/lib/utils";

export async function createTask(params: {
  title: string;
  description?: string;
  minuteId?: string;
  responsibleIds: string[];
  assignerId: string;
  priority: TaskPriority;
  dueDate: Date;
  isRecurring?: boolean;
  recurrenceRule?: string;
  explanation?: string;
}) {
  const selfOnly = params.responsibleIds.length === 1 && params.responsibleIds[0] === params.assignerId;

  const task = await db.task.create({
    data: {
      title: params.title,
      description: params.description,
      minuteId: params.minuteId,
      assignerId: params.assignerId,
      priority: params.priority,
      dueDate: params.dueDate,
      isRecurring: params.isRecurring ?? false,
      recurrenceRule: params.recurrenceRule,
      explanation: params.explanation,
      needsApproval: !selfOnly,
      approvalStatus: selfOnly ? "ACCEPTED" : "PENDING",
      status: "IN_PROGRESS",
      assignees: {
        create: params.responsibleIds.map((userId) => ({ userId }))
      }
    },
    include: { assignees: { include: { user: true } } }
  });

  if (!selfOnly) {
    await notifyManyUsers(params.responsibleIds, {
      type: "TASK_ASSIGNED",
      title: `تسک جدید: ${task.title}`,
      message: `یک تسک جدید با مهلت ${formatJalaliDate(task.dueDate)} به شما اساین شد. لطفا آن را تایید یا زمان جایگزین پیشنهاد دهید.`,
      smsText: `تسک جدید «${task.title}» - مهلت: ${formatJalaliDate(task.dueDate)}`,
      relatedTaskId: task.id
    });
  }

  return task;
}

export async function respondToTaskAssignment(params: {
  taskId: string;
  accept: boolean;
  proposedDueDate?: Date;
  note?: string;
}) {
  const task = await db.task.update({
    where: { id: params.taskId },
    data: {
      approvalStatus: params.accept
        ? "ACCEPTED"
        : params.proposedDueDate
          ? "RESCHEDULE_PROPOSED"
          : "REJECTED",
      proposedDueDate: params.proposedDueDate,
      explanation: params.note
    },
    include: { assigner: true, assignees: { include: { user: true } } }
  });

  const assigneeNames = task.assignees.map((a) => a.user.fullName).join("، ");

  await notifyUser({
    userId: task.assignerId,
    type: "TASK_STATUS_CHANGE",
    title: `پاسخ به تسک: ${task.title}`,
    message: params.accept
      ? `${assigneeNames} تسک «${task.title}» را پذیرفت.`
      : params.proposedDueDate
        ? `${assigneeNames} برای تسک «${task.title}» مهلت جایگزین پیشنهاد داد.`
        : `${assigneeNames} تسک «${task.title}» را رد کرد.`,
    relatedTaskId: task.id
  });

  return task;
}

// تایید نهاییِ مهلتِ جایگزینِ پیشنهادی توسط اساین‌کننده
export async function approveProposedDueDate(taskId: string) {
  const task = await db.task.findUniqueOrThrow({ where: { id: taskId } });
  if (!task.proposedDueDate) throw new Error("پیشنهادی برای این تسک ثبت نشده است");

  return db.task.update({
    where: { id: taskId },
    data: {
      dueDate: task.proposedDueDate,
      proposedDueDate: null,
      approvalStatus: "ACCEPTED"
    }
  });
}

// تغییر وضعیت دستی توسط مسئول تسک: در حال انجام / نیازمند زمان بیشتر / منتظر دیگری / انجام شده / لغو شده
export async function setTaskStatus(taskId: string, status: TaskStatus, note?: string) {
  if (!MANUAL_TASK_STATUSES.includes(status)) {
    throw new Error("این وضعیت به‌صورت دستی قابل تنظیم نیست");
  }
  const task = await db.task.update({
    where: { id: taskId },
    data: {
      status,
      doneAt: status === "GREEN_DONE" ? new Date() : null,
      explanation: note ?? undefined
    },
    include: { assigner: true, assignees: { include: { user: true } } }
  });

  const assigneeNames = task.assignees.map((a) => a.user.fullName).join("، ");
  await notifyUser({
    userId: task.assignerId,
    type: "TASK_STATUS_CHANGE",
    title: `تغییر وضعیت تسک: ${task.title}`,
    message: `${assigneeNames} وضعیت تسک «${task.title}» را تغییر داد.${note ? ` توضیح: ${note}` : ""}`,
    relatedTaskId: task.id
  });

  return task;
}

export async function markTaskDone(taskId: string) {
  return setTaskStatus(taskId, "GREEN_DONE");
}

export async function addTaskComment(params: { taskId: string; authorId: string; body: string }) {
  const comment = await db.taskComment.create({
    data: { taskId: params.taskId, authorId: params.authorId, body: params.body },
    include: { author: true, task: { include: { assignees: true } } }
  });

  const notifyIds = new Set(comment.task.assignees.map((a) => a.userId));
  notifyIds.delete(params.authorId);
  if (notifyIds.size > 0) {
    await notifyManyUsers([...notifyIds], {
      type: "TASK_STATUS_CHANGE",
      title: `نظر جدید روی تسک`,
      message: `${comment.author.fullName} روی یک مصوبه‌ی مشترک نظر ثبت کرد.`,
      relatedTaskId: params.taskId
    });
  }

  return comment;
}

// این تابع باید به‌صورت دوره‌ای (مثلا هر شب) اجرا شود تا وضعیت رنگی همه‌ی تسک‌های باز به‌روز شود
export async function refreshAllTaskStatuses() {
  const openTasks = await db.task.findMany({
    where: { doneAt: null, status: { notIn: ["NEEDS_MORE_TIME", "WAITING_ON_OTHERS", "CANCELED"] } }
  });
  let updated = 0;
  for (const t of openTasks) {
    const newStatus = computeTaskStatus(t.dueDate, t.doneAt);
    if (newStatus !== t.status) {
      await db.task.update({ where: { id: t.id }, data: { status: newStatus } });
      updated++;
    }
  }
  return { checked: openTasks.length, updated };
}
