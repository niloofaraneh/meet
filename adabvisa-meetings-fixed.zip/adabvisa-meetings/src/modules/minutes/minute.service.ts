/**
 * سرویس صورتجلسات.
 * شماره‌گذاری خودکار به فرم «سال‌شمسی/کد‌واحد/شماره‌ترتیبی» است، دقیقا مطابق
 * نمونه‌ی مشاهده‌شده در فرم G20 (مثلا 1404/الف/110).
 */
import { db } from "@/lib/db";
import { currentJalaliYear } from "@/lib/jalali";

export async function generateMinuteNumber(unitId: string): Promise<string> {
  const unit = await db.unit.update({
    where: { id: unitId },
    data: { minuteSeq: { increment: 1 } }
  });
  const year = currentJalaliYear();
  return `${year}/${unit.code}/${unit.minuteSeq}`;
}

export async function createMeetingMinute(params: {
  meetingId: string;
  unitId: string;
  recorderId: string;
  summary?: string;
  attachmentUrl?: string;
}) {
  const number = await generateMinuteNumber(params.unitId);
  return db.meetingMinute.create({
    data: {
      number,
      meetingId: params.meetingId,
      recorderId: params.recorderId,
      summary: params.summary,
      attachmentUrl: params.attachmentUrl
    }
  });
}
