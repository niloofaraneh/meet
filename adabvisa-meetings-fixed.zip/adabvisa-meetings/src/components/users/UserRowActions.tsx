"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";

type UnitOption = { id: string; name: string };
type PositionOption = { id: string; title: string };

type UserRow = {
  id: string;
  fullName: string;
  phone: string;
  email: string | null;
  unitId: string | null;
  positionId: string | null;
  isActive: boolean;
};

export function UserRowActions({
  user,
  units,
  positions
}: {
  user: UserRow;
  units: UnitOption[];
  positions: PositionOption[];
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(user.fullName);
  const [phone, setPhone] = useState(user.phone);
  const [email, setEmail] = useState(user.email ?? "");
  const [unitId, setUnitId] = useState(user.unitId ?? "");
  const [positionId, setPositionId] = useState(user.positionId ?? "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/users/${user.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, phone, email, unitId: unitId || null, positionId: positionId || null })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ویرایش پرسنل");
        return;
      }
      setEditing(false);
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function remove() {
    if (!confirm(`${user.fullName} حذف/غیرفعال شود؟`)) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/users/${user.id}`, { method: "DELETE" });
      const json = await res.json();
      if (json.success) router.refresh();
      else alert(json.error ?? "خطا در حذف");
    } finally {
      setLoading(false);
    }
  }

  async function toggleActive() {
    setLoading(true);
    try {
      await fetch(`/api/users/${user.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !user.isActive })
      });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (editing) {
    return (
      <tr className="border-b border-navy-50/70 bg-navy-50/30">
        <td colSpan={4} className="p-3">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-2">
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} className="rounded-lg border border-navy-100 px-3 py-1.5 text-sm" placeholder="نام" />
            <input value={phone} onChange={(e) => setPhone(e.target.value)} dir="ltr" className="rounded-lg border border-navy-100 px-3 py-1.5 text-sm" placeholder="موبایل" />
            <input value={email} onChange={(e) => setEmail(e.target.value)} dir="ltr" className="rounded-lg border border-navy-100 px-3 py-1.5 text-sm" placeholder="ایمیل" />
            <select value={unitId} onChange={(e) => setUnitId(e.target.value)} className="rounded-lg border border-navy-100 px-3 py-1.5 text-sm">
              <option value="">بدون واحد</option>
              {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <select value={positionId} onChange={(e) => setPositionId(e.target.value)} className="rounded-lg border border-navy-100 px-3 py-1.5 text-sm col-span-2">
              <option value="">بدون سمت تعریف‌شده</option>
              {positions.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
            </select>
          </div>
          {error && <p className="text-xs text-status-danger mb-2">{error}</p>}
          <div className="flex gap-2">
            <Button disabled={loading} onClick={save}>ذخیره</Button>
            <Button variant="ghost" onClick={() => setEditing(false)}>انصراف</Button>
          </div>
        </td>
      </tr>
    );
  }

  return (
    <div className="flex items-center gap-2 justify-end">
      <button onClick={() => setEditing(true)} className="text-xs text-navy-400 hover:text-navy-700">ویرایش</button>
      <button onClick={toggleActive} disabled={loading} className="text-xs text-navy-400 hover:text-navy-700">
        {user.isActive ? "غیرفعال" : "فعال"}
      </button>
      <button onClick={remove} disabled={loading} className="text-xs text-status-danger hover:underline">حذف</button>
    </div>
  );
}
