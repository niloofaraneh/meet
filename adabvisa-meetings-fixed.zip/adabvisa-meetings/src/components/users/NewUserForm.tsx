"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { ROLE_LABELS } from "@/lib/constants";

const roles = Object.keys(ROLE_LABELS) as (keyof typeof ROLE_LABELS)[];

export function NewUserForm({
  units,
  positions
}: {
  units: { id: string; name: string }[];
  positions: { id: string; title: string }[];
}) {
  const router = useRouter();
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    email: "",
    password: "",
    role: "STAFF",
    unitId: units[0]?.id ?? "",
    positionId: positions[0]?.id ?? ""
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت کاربر");
        return;
      }
      setForm((f) => ({ ...f, fullName: "", phone: "", email: "", password: "" }));
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} placeholder="نام و نام‌خانوادگی" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
      <input value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="09xxxxxxxxx" dir="ltr" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
      <input value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="ایمیل (اختیاری)" dir="ltr" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" />
      <input type="password" value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} placeholder="رمز عبور اولیه" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />

      <div>
        <label className="block text-xs text-navy-500 mb-1">سمت سازمانی (سطح دسترسی از این سمت گرفته می‌شود)</label>
        <select value={form.positionId} onChange={(e) => setForm((f) => ({ ...f, positionId: e.target.value }))} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
          <option value="">بدون سمت تعریف‌شده (دسترسی پایه)</option>
          {positions.map((p) => <option key={p.id} value={p.id}>{p.title}</option>)}
        </select>
        {positions.length === 0 && (
          <p className="text-[11px] text-navy-400 mt-1">هنوز سمتی تعریف نشده؛ از صفحه‌ی «سمت‌ها و دسترسی‌ها» یکی بسازید.</p>
        )}
      </div>

      <div>
        <label className="block text-xs text-navy-500 mb-1">رتبه‌ی نمایشی (فقط برای رنگ/سازگاری، دسترسی واقعی از سمت گرفته می‌شود)</label>
        <select value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
          {roles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
        </select>
      </div>

      <select value={form.unitId} onChange={(e) => setForm((f) => ({ ...f, unitId: e.target.value }))} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
        {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
      </select>
      {error && <p className="text-sm text-status-danger">{error}</p>}
      <Button type="submit" disabled={loading}>{loading ? "در حال ثبت..." : "+ افزودن پرسنل"}</Button>
    </form>
  );
}
