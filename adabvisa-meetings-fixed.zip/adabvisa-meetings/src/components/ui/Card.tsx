import { cn } from "@/lib/utils";
import { ReactNode } from "react";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("bg-white rounded-2xl shadow-card border border-navy-50 p-5", className)}>
      {children}
    </div>
  );
}
