import { Card } from "./Card";
import { ReactNode } from "react";

export function StatCard({
  label,
  value,
  icon,
  color = "#1f2c4d"
}: {
  label: string;
  value: string | number;
  icon?: ReactNode;
  color?: string;
}) {
  return (
    <Card className="flex items-center justify-between">
      <div>
        <p className="text-sm text-navy-400 mb-1">{label}</p>
        <p className="text-2xl font-bold text-navy-800">{value}</p>
      </div>
      {icon && (
        <div
          className="w-11 h-11 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${color}1a`, color }}
        >
          {icon}
        </div>
      )}
    </Card>
  );
}
