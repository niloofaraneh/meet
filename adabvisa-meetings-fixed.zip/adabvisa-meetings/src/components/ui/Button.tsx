import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes } from "react";

type Variant = "primary" | "secondary" | "danger" | "ghost";

const variantClasses: Record<Variant, string> = {
  primary: "bg-navy-800 hover:bg-navy-700 text-white",
  secondary: "bg-navy-50 hover:bg-navy-100 text-navy-800",
  danger: "bg-status-danger/10 hover:bg-status-danger/20 text-status-danger",
  ghost: "hover:bg-navy-50 text-navy-700"
};

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      className={cn(
        "px-4 py-2 rounded-xl text-sm font-medium transition disabled:opacity-50 disabled:cursor-not-allowed",
        variantClasses[variant],
        className
      )}
      {...props}
    />
  );
}
