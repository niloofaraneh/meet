"use client";
import { useEffect, useRef, useState } from "react";
import jalaali from "jalaali-js";
import { jalaliMonthNames, jalaliWeekDays } from "@/lib/jalali";

type Props = {
  value: string; // فرمت yyyy/mm/dd یا خالی
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  className?: string;
};

// انتخابگر تاریخ شمسی کاملا لوکال (بدون هیچ سرویس بیرونی) - نمایش ماه و کلیک روی روز
export function JalaliDatePicker({ value, onChange, placeholder = "انتخاب تاریخ", required, className }: Props) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const parsed = value ? value.split("/").map((p) => parseInt(p, 10)) : null;
  const today = jalaali.toJalaali(new Date());

  const [viewYear, setViewYear] = useState(parsed?.[0] ?? today.jy);
  const [viewMonth, setViewMonth] = useState(parsed?.[1] ?? today.jm);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  const monthNames = jalaliMonthNames();
  // هفته‌ی ایرانی از شنبه شروع می‌شود؛ آرایه‌ی پایه با یکشنبه شروع می‌شود پس می‌چرخانیم
  const baseWeekDays = jalaliWeekDays();
  const weekDays = [...baseWeekDays.slice(6), ...baseWeekDays.slice(0, 6)];

  const daysInMonth = jalaali.jalaaliMonthLength(viewYear, viewMonth);
  // آفست روز اول ماه در هفته (شنبه = ۰ در تقویم ایرانی)
  const firstDayGregorian = jalaali.toGregorian(viewYear, viewMonth, 1);
  const firstDayDate = new Date(firstDayGregorian.gy, firstDayGregorian.gm - 1, firstDayGregorian.gd);
  const jsWeekDay = firstDayDate.getDay(); // 0=یکشنبه ... 6=شنبه در جاوااسکریپت
  const offset = (jsWeekDay + 1) % 7; // تبدیل به شنبه=۰

  function selectDay(day: number) {
    const str = `${viewYear}/${String(viewMonth).padStart(2, "0")}/${String(day).padStart(2, "0")}`;
    onChange(str);
    setOpen(false);
  }

  function goPrevMonth() {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  }

  function goNextMonth() {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  }

  const cells: (number | null)[] = [...Array(offset).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];

  return (
    <div className="relative" ref={containerRef}>
      <input
        readOnly
        value={value}
        onClick={() => setOpen((o) => !o)}
        placeholder={placeholder}
        dir="ltr"
        required={required}
        className={className ?? "w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm cursor-pointer bg-white"}
      />
      {open && (
        <div className="absolute z-30 mt-1 w-72 bg-white rounded-2xl shadow-card border border-navy-50 p-3">
          <div className="flex items-center justify-between mb-2">
            <button type="button" onClick={goPrevMonth} className="w-7 h-7 rounded-lg hover:bg-navy-50 text-navy-600">‹</button>
            <span className="text-sm font-medium text-navy-800">{monthNames[viewMonth - 1]} {viewYear}</span>
            <button type="button" onClick={goNextMonth} className="w-7 h-7 rounded-lg hover:bg-navy-50 text-navy-600">›</button>
          </div>
          <div className="grid grid-cols-7 gap-1 mb-1">
            {weekDays.map((d) => (
              <div key={d} className="text-[10px] text-navy-300 text-center">{d.slice(0, 2)}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, idx) => {
              const isSelected = day !== null && parsed && parsed[0] === viewYear && parsed[1] === viewMonth && parsed[2] === day;
              const isToday = day !== null && today.jy === viewYear && today.jm === viewMonth && today.jd === day;
              return (
                <button
                  type="button"
                  key={idx}
                  disabled={day === null}
                  onClick={() => day && selectDay(day)}
                  className={`h-8 rounded-lg text-xs ${
                    day === null
                      ? ""
                      : isSelected
                        ? "bg-navy-800 text-white font-medium"
                        : isToday
                          ? "border border-navy-300 text-navy-700"
                          : "hover:bg-navy-50 text-navy-700"
                  }`}
                >
                  {day ?? ""}
                </button>
              );
            })}
          </div>
          <button
            type="button"
            onClick={() => {
              setViewYear(today.jy);
              setViewMonth(today.jm);
            }}
            className="w-full mt-2 text-xs text-navy-500 hover:text-navy-800 py-1"
          >
            رفتن به ماه جاری
          </button>
        </div>
      )}
    </div>
  );
}
