"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { JalaliDatePicker } from "@/components/ui/JalaliDatePicker";

type UserOption = { id: string; fullName: string };

type Row = {
  key: number;
  title: string;
  explanation: string;
  responsibleIds: string[];
  priority: string;
  jalaliDueDate: string;
  isRecurring: boolean;
};

function emptyRow(key: number): Row {
  return { key, title: "", explanation: "", responsibleIds: [], priority: "NORMAL", jalaliDueDate: "", isRecurring: false };
}

// فرم افزودن یک یا چند مصوبه/تسک هم‌زمان برای یک صورتجلسه؛ هرکدام مستقل با چند مسئول و ددلاین خودشان
export function AddTaskForm({ minuteId, users }: { minuteId?: string; users: UserOption[] }) {
  const router = useRouter();
  const [rows, setRows] = useState<Row[]>([emptyRow(0)]);
  const [nextKey, setNextKey] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function updateRow(key: number, patch: Partial<Row>) {
    setRows((prev) => prev.map((r) => (r.key === key ? { ...r, ...patch } : r)));
  }

  function toggleResponsible(key: number, userId: string) {
    setRows((prev) =>
      prev.map((r) =>
        r.key === key
          ? { ...r, responsibleIds: r.responsibleIds.includes(userId) ? r.responsibleIds.filter((x) => x !== userId) : [...r.responsibleIds, userId] }
          : r
      )
    );
  }

  function addRow() {
    setRows((prev) => [...prev, emptyRow(nextKey)]);
    setNextKey((k) => k + 1);
  }

  function removeRow(key: number) {
    setRows((prev) => (prev.length === 1 ? prev : prev.filter((r) => r.key !== key)));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    for (const r of rows) {
      if (!r.title || r.responsibleIds.length === 0 || !r.jalaliDueDate) {
        setError("برای هر مصوبه، موضوع، حداقل یک مسئول پیگیری و مهلت اجرا الزامی است.");
        return;
      }
    }

    setLoading(true);
    try {
      for (const r of rows) {
        const res = await fetch("/api/tasks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: r.title,
            explanation: r.explanation,
            minuteId,
            responsibleIds: r.responsibleIds,
            priority: r.priority,
            jalaliDueDate: r.jalaliDueDate,
            isRecurring: r.isRecurring
          })
        });
        const json = await res.json();
        if (!json.success) {
          setError(json.error ?? "خطا در ثبت مصوبه");
          setLoading(false);
          return;
        }
      }
      setRows([emptyRow(nextKey)]);
      setNextKey((k) => k + 1);
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {rows.map((r, idx) => (
        <div key={r.key} className="rounded-2xl border border-navy-100 p-4 space-y-3 relative">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-navy-400">مصوبه {idx + 1}</span>
            {rows.length > 1 && (
              <button type="button" onClick={() => removeRow(r.key)} className="text-xs text-status-danger hover:underline">
                حذف
              </button>
            )}
          </div>

          <input
            value={r.title}
            onChange={(e) => updateRow(r.key, { title: e.target.value })}
            placeholder="موضوع مصوبه"
            className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm"
          />
          <textarea
            value={r.explanation}
            onChange={(e) => updateRow(r.key, { explanation: e.target.value })}
            placeholder="توضیحات (اختیاری)"
            rows={2}
            className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm"
          />

          <div>
            <label className="block text-xs text-navy-500 mb-1.5">مسئولین پیگیری (چند نفر قابل انتخاب است)</label>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 rounded-xl border border-navy-100">
              {users.map((u) => {
                const selected = r.responsibleIds.includes(u.id);
                return (
                  <button
                    type="button"
                    key={u.id}
                    onClick={() => toggleResponsible(r.key, u.id)}
                    className={`text-xs px-2.5 py-1.5 rounded-full border ${
                      selected ? "bg-navy-800 text-white border-navy-800" : "border-navy-100 text-navy-600 hover:bg-navy-50"
                    }`}
                  >
                    {u.fullName}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <select value={r.priority} onChange={(e) => updateRow(r.key, { priority: e.target.value })} className="rounded-xl border border-navy-100 px-3 py-2.5 text-sm">
              <option value="LOW">اولویت کم</option>
              <option value="NORMAL">اولویت عادی</option>
              <option value="HIGH">اولویت بالا</option>
              <option value="URGENT">فوری</option>
            </select>
            <JalaliDatePicker
              value={r.jalaliDueDate}
              onChange={(v) => updateRow(r.key, { jalaliDueDate: v })}
              placeholder="مهلت اجرا"
              className="rounded-xl border border-navy-100 px-3 py-2.5 text-sm cursor-pointer bg-white w-full"
            />
            <label className="flex items-center gap-2 text-sm text-navy-600 px-1 col-span-2">
              <input type="checkbox" checked={r.isRecurring} onChange={(e) => updateRow(r.key, { isRecurring: e.target.checked })} />
              تسک تکرارشونده
            </label>
          </div>
        </div>
      ))}

      <button type="button" onClick={addRow} className="text-sm text-navy-600 hover:text-navy-800 border border-dashed border-navy-200 rounded-xl w-full py-2.5">
        + افزودن مصوبه دیگر
      </button>

      {error && <p className="text-sm text-status-danger">{error}</p>}
      <Button type="submit" disabled={loading} variant="secondary">
        {loading ? "در حال ثبت..." : `ثبت ${rows.length > 1 ? `${rows.length} مصوبه` : "مصوبه"}`}
      </Button>
    </form>
  );
}
