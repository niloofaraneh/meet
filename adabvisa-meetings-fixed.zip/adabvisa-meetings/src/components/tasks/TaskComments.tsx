"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { formatJalaliDateTime } from "@/lib/jalali";

type Comment = {
  id: string;
  body: string;
  createdAt: string;
  author: { id: string; fullName: string; avatarUrl: string | null };
};

export function TaskComments({ taskId, comments }: { taskId: string; comments: Comment[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setLoading(true);
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "addComment", body: text.trim() })
      });
      setText("");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mt-2">
      <button type="button" onClick={() => setOpen((o) => !o)} className="text-xs text-navy-400 hover:text-navy-700">
        {comments.length > 0 ? `${comments.length} نظر` : "افزودن نظر"}
      </button>
      {open && (
        <div className="mt-2 space-y-2 bg-navy-50/40 rounded-xl p-3">
          {comments.map((c) => (
            <div key={c.id} className="flex items-start gap-2">
              <Avatar name={c.author.fullName} url={c.author.avatarUrl} size={22} />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-navy-700"><span className="font-medium">{c.author.fullName}</span> — {formatJalaliDateTime(c.createdAt)}</p>
                <p className="text-sm text-navy-600 whitespace-pre-line">{c.body}</p>
              </div>
            </div>
          ))}
          <form onSubmit={submit} className="flex gap-2 pt-1">
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="نظر یا توضیح خود را بنویسید..."
              className="flex-1 rounded-lg border border-navy-100 px-3 py-2 text-xs"
            />
            <Button type="submit" disabled={loading} variant="secondary">ارسال</Button>
          </form>
        </div>
      )}
    </div>
  );
}
