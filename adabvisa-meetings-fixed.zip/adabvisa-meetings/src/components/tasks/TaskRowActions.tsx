"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { MANUAL_TASK_STATUS_OPTIONS, TASK_STATUS_LABELS } from "@/lib/constants";

export function TaskRowActions({
  taskId,
  approvalStatus,
  isDone,
  currentStatus,
  canChangeStatus
}: {
  taskId: string;
  approvalStatus: string;
  isDone: boolean;
  currentStatus: string;
  canChangeStatus: boolean;
}) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function act(body: any) {
    setLoading(true);
    try {
      await fetch(`/api/tasks/${taskId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (approvalStatus === "PENDING") {
    return (
      <div className="flex gap-1.5">
        <Button variant="secondary" disabled={loading} onClick={() => act({ action: "respond", accept: true })}>تایید</Button>
        <Button variant="danger" disabled={loading} onClick={() => act({ action: "respond", accept: false })}>رد</Button>
      </div>
    );
  }

  if (!canChangeStatus) return null;

  return (
    <select
      value={currentStatus}
      disabled={loading}
      onChange={(e) => act({ action: "setStatus", status: e.target.value })}
      className="text-xs rounded-lg border border-navy-100 px-2 py-1.5 bg-white"
    >
      {MANUAL_TASK_STATUS_OPTIONS.map((s) => (
        <option key={s} value={s}>{TASK_STATUS_LABELS[s]}</option>
      ))}
    </select>
  );
}
