"use client";
import { Button } from "@/components/ui/Button";

export function ExportButton({ unitId, responsibleId }: { unitId?: string; responsibleId?: string }) {
  function handleExport() {
    const params = new URLSearchParams();
    if (unitId) params.set("unitId", unitId);
    if (responsibleId) params.set("responsibleId", responsibleId);
    window.location.href = `/api/tasks/export?${params.toString()}`;
  }

  return (
    <Button variant="secondary" onClick={handleExport}>
      خروجی اکسل مصوبات
    </Button>
  );
}
