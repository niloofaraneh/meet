"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export function NewMinuteForm({
  meetingId,
  units
}: {
  meetingId: string;
  units: { id: string; name: string; code: string }[];
}) {
  const router = useRouter();
  const [unitId, setUnitId] = useState(units[0]?.id ?? "");
  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/minutes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ meetingId, unitId, summary })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت صورتجلسه");
        return;
      }
      router.push(`/minutes/${json.data.id}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Card className="space-y-4">
        <div>
          <label className="block text-sm text-navy-700 mb-1.5">واحد مربوطه (برای شماره‌گذاری خودکار)</label>
          <select value={unitId} onChange={(e) => setUnitId(e.target.value)} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
            {units.map((u) => (
              <option key={u.id} value={u.id}>{u.name} (کد {u.code})</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm text-navy-700 mb-1.5">خلاصه مذاکرات</label>
          <textarea value={summary} onChange={(e) => setSummary(e.target.value)} rows={5} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" placeholder="خلاصه‌ای از آنچه در جلسه مطرح شد..." />
        </div>
      </Card>
      {error && <p className="text-sm text-status-danger">{error}</p>}
      <div className="flex justify-end">
        <Button type="submit" disabled={loading}>{loading ? "در حال ثبت..." : "ثبت صورتجلسه و ادامه"}</Button>
      </div>
    </form>
  );
}
