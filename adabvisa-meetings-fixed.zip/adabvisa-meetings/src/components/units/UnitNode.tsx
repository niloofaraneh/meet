"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

type UnitNodeData = {
  id: string;
  name: string;
  code: string;
  colorHex: string;
  isActive: boolean;
  _count?: { users: number };
  users?: unknown[];
  children?: UnitNodeData[];
};

export function UnitNode({ unit, depth = 0 }: { unit: UnitNodeData; depth?: number }) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(unit.name);
  const [code, setCode] = useState(unit.code);
  const [colorHex, setColorHex] = useState(unit.colorHex);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function save() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/units/${unit.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, code, colorHex })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ویرایش واحد");
        return;
      }
      setEditing(false);
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  async function remove() {
    if (!confirm(`واحد «${unit.name}» حذف/غیرفعال شود؟`)) return;
    setLoading(true);
    try {
      await fetch(`/api/units/${unit.id}`, { method: "DELETE" });
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  if (editing) {
    return (
      <div className="p-3 rounded-xl border border-navy-100 space-y-2" style={{ marginRight: depth * 20 }}>
        <div className="flex items-center gap-2">
          <input value={name} onChange={(e) => setName(e.target.value)} className="flex-1 rounded-lg border border-navy-100 px-3 py-1.5 text-sm" />
          <input value={code} onChange={(e) => setCode(e.target.value)} className="w-16 rounded-lg border border-navy-100 px-3 py-1.5 text-sm" />
          <input type="color" value={colorHex} onChange={(e) => setColorHex(e.target.value)} className="w-9 h-9 rounded-lg border border-navy-100" />
        </div>
        {error && <p className="text-xs text-status-danger">{error}</p>}
        <div className="flex gap-2">
          <Button disabled={loading} onClick={save}>ذخیره</Button>
          <Button variant="ghost" onClick={() => setEditing(false)}>انصراف</Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        className="flex items-center justify-between p-3 rounded-xl hover:bg-navy-50/50 group"
        style={{ marginRight: depth * 20 }}
      >
        <div className="flex items-center gap-2.5">
          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: unit.colorHex }} />
          <span className="text-sm font-medium text-navy-800">{unit.name}</span>
          <span className="text-xs text-navy-300">کد: {unit.code}</span>
          {!unit.isActive && <Badge color="#8a94a6">غیرفعال</Badge>}
        </div>
        <div className="flex items-center gap-2">
          <Badge color={unit.colorHex}>{unit._count?.users ?? unit.users?.length ?? 0} نفر</Badge>
          <button onClick={() => setEditing(true)} className="text-xs text-navy-400 hover:text-navy-700 opacity-0 group-hover:opacity-100 transition">ویرایش</button>
          <button onClick={remove} disabled={loading} className="text-xs text-status-danger opacity-0 group-hover:opacity-100 transition">حذف</button>
        </div>
      </div>
      {unit.children?.map((c) => (
        <UnitNode key={c.id} unit={c} depth={depth + 1} />
      ))}
    </div>
  );
}
