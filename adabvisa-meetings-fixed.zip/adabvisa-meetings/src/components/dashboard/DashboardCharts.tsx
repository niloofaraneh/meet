"use client";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

export function UnitTasksBarChart({
  data
}: {
  data: { unitName: string; taskCount: number; color: string }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#eef1f7" />
        <XAxis dataKey="unitName" tick={{ fontSize: 12, fontFamily: "Vazirmatn" }} />
        <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
        <Tooltip
          contentStyle={{ fontFamily: "Vazirmatn", fontSize: 12, borderRadius: 12, border: "1px solid #eef1f7" }}
        />
        <Bar dataKey="taskCount" name="تعداد مصوبات" radius={[8, 8, 0, 0]}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export function TaskStatusPieChart({
  data
}: {
  data: { name: string; value: number; color: string }[];
}) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
          {data.map((d, i) => (
            <Cell key={i} fill={d.color} />
          ))}
        </Pie>
        <Legend wrapperStyle={{ fontFamily: "Vazirmatn", fontSize: 12 }} />
        <Tooltip contentStyle={{ fontFamily: "Vazirmatn", fontSize: 12, borderRadius: 12 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}
