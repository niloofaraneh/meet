"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Avatar } from "@/components/ui/Avatar";
import { JalaliDatePicker } from "@/components/ui/JalaliDatePicker";

type UserOption = { id: string; fullName: string; unitName: string; avatarUrl: string | null };

type BusySlot = { meetingId: string; title: string; start: string; end: string };

export function NewMeetingForm({ users }: { users: UserOption[] }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [jalaliDate, setJalaliDate] = useState(""); // yyyy/mm/dd
  const [startTime, setStartTime] = useState("10:00");
  const [endTime, setEndTime] = useState("11:00");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [conflicts, setConflicts] = useState<Record<string, BusySlot[]>>({});
  const [checking, setChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  function toggleUser(id: string) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
    setConflicts({});
  }

  function buildIsoDates(): { start: string; end: string } | null {
    const parts = jalaliDate.split("/").map((p) => parseInt(p.trim(), 10));
    if (parts.length !== 3 || parts.some((p) => Number.isNaN(p))) return null;
    // تبدیل ساده jalali->gregorian سمت کلاینت با فراخوانی API انجام نمی‌شود؛
    // به همین دلیل تاریخ خام jalali را همراه ساعت به سرور می‌فرستیم و خود سرور تبدیل می‌کند.
    return null;
  }

  async function checkAvailability() {
    if (selectedIds.length === 0 || !jalaliDate) return;
    setChecking(true);
    setError("");
    try {
      const res = await fetch("/api/availability", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userIds: selectedIds,
          jalaliDate,
          startTime,
          endTime
        })
      });
      const json = await res.json();
      if (json.success) setConflicts(json.data);
    } finally {
      setChecking(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!title || !jalaliDate || selectedIds.length === 0) {
      setError("عنوان، تاریخ و حداقل یک حاضر الزامی است.");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/meetings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          location,
          jalaliDate,
          startTime,
          endTime,
          attendeeIds: selectedIds
        })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت جلسه");
        return;
      }
      router.push(`/meetings/${json.data.id}`);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <Card className="space-y-4">
        <div>
          <label className="block text-sm text-navy-700 mb-1.5">عنوان جلسه</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
        </div>
        <div>
          <label className="block text-sm text-navy-700 mb-1.5">توضیحات / دستور جلسه</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" />
        </div>
        <div>
          <label className="block text-sm text-navy-700 mb-1.5">مکان برگزاری</label>
          <input value={location} onChange={(e) => setLocation(e.target.value)} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" placeholder="مثلا اتاق جلسات طبقه ۳" />
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-sm text-navy-700 mb-1.5">تاریخ (شمسی)</label>
            <JalaliDatePicker value={jalaliDate} onChange={setJalaliDate} placeholder="انتخاب تاریخ" required />
          </div>
          <div>
            <label className="block text-sm text-navy-700 mb-1.5">ساعت شروع</label>
            <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} dir="ltr" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
          </div>
          <div>
            <label className="block text-sm text-navy-700 mb-1.5">ساعت پایان</label>
            <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} dir="ltr" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm text-navy-700">حاضرین جلسه</label>
          <Button type="button" variant="secondary" onClick={checkAvailability} disabled={checking || selectedIds.length === 0 || !jalaliDate}>
            {checking ? "در حال بررسی..." : "بررسی تایم خالی"}
          </Button>
        </div>
        <div className="max-h-72 overflow-y-auto space-y-1.5 pr-1">
          {users.map((u) => {
            const isSelected = selectedIds.includes(u.id);
            const userConflicts = conflicts[u.id] ?? [];
            return (
              <div
                key={u.id}
                onClick={() => toggleUser(u.id)}
                className={`flex items-center justify-between p-2.5 rounded-xl cursor-pointer border ${
                  isSelected ? "border-navy-600 bg-navy-50/60" : "border-transparent hover:bg-navy-50/40"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Avatar name={u.fullName} url={u.avatarUrl} size={30} />
                  <div>
                    <p className="text-sm text-navy-800">{u.fullName}</p>
                    <p className="text-xs text-navy-400">{u.unitName}</p>
                  </div>
                </div>
                {isSelected && userConflicts.length > 0 && (
                  <span className="text-[11px] text-status-danger">در این بازه جلسه دارد</span>
                )}
                {isSelected && conflicts[u.id] !== undefined && userConflicts.length === 0 && (
                  <span className="text-[11px] text-status-success">در این بازه آزاد است</span>
                )}
              </div>
            );
          })}
        </div>
      </Card>

      {error && <p className="text-sm text-status-danger">{error}</p>}

      <div className="flex justify-end gap-3">
        <Button type="submit" disabled={submitting}>{submitting ? "در حال ثبت..." : "ثبت درخواست جلسه"}</Button>
      </div>
    </form>
  );
}
