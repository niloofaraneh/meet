"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

type Position = {
  id: string;
  title: string;
  description: string | null;
  canManageOrgWide: boolean;
  canViewAllOrg: boolean;
  canViewUnitStaff: boolean;
  canCreateMeeting: boolean;
  canCreateMinute: boolean;
  canExportExcel: boolean;
  isActive: boolean;
  _count?: { users: number };
};

const flagLabels: { key: keyof Position; label: string }[] = [
  { key: "canManageOrgWide", label: "مدیریت کل" },
  { key: "canViewAllOrg", label: "دیدن کل سازمان" },
  { key: "canViewUnitStaff", label: "دیدن زیرمجموعه واحد" },
  { key: "canCreateMeeting", label: "ثبت جلسه" },
  { key: "canCreateMinute", label: "ثبت صورتجلسه" },
  { key: "canExportExcel", label: "خروجی اکسل" }
];

export function PositionsList({ positions }: { positions: Position[] }) {
  const router = useRouter();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState("");

  async function toggleActive(p: Position) {
    setBusyId(p.id);
    try {
      await fetch(`/api/positions/${p.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !p.isActive })
      });
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function remove(p: Position) {
    if (!confirm(`سمت «${p.title}» حذف شود؟`)) return;
    setBusyId(p.id);
    setError("");
    try {
      const res = await fetch(`/api/positions/${p.id}`, { method: "DELETE" });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در حذف سمت");
        return;
      }
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-2">
      {error && <p className="text-sm text-status-danger">{error}</p>}
      {positions.map((p) => (
        <div key={p.id} className="border border-navy-50 rounded-xl p-3">
          <div className="flex items-center justify-between mb-2">
            <div>
              <p className="text-sm font-medium text-navy-800">{p.title}</p>
              {p.description && <p className="text-xs text-navy-400">{p.description}</p>}
            </div>
            <div className="flex items-center gap-2">
              <Badge color={p.isActive ? "#3f9e5e" : "#8a94a6"}>{p._count?.users ?? 0} نفر</Badge>
              <Button variant="secondary" disabled={busyId === p.id} onClick={() => toggleActive(p)}>
                {p.isActive ? "غیرفعال کردن" : "فعال کردن"}
              </Button>
              <Button variant="danger" disabled={busyId === p.id} onClick={() => remove(p)}>حذف</Button>
            </div>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {flagLabels.filter((f) => p[f.key]).map((f) => (
              <Badge key={String(f.key)} color="#3574c4">{f.label}</Badge>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
