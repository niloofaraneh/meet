"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { ROLE_LABELS } from "@/lib/constants";

const permissionFields: { key: string; label: string; hint: string }[] = [
  { key: "canManageOrgWide", label: "مدیریت کامل سازمان", hint: "مدیریت پرسنل، واحدها و سمت‌ها در کل سازمان" },
  { key: "canViewAllOrg", label: "مشاهده کل سازمان", hint: "دیدن جلسات و تسک‌های همه‌ی واحدها" },
  { key: "canViewUnitStaff", label: "مشاهده زیرمجموعه واحد", hint: "مثلا مدیر واحد بتواند تسک‌های سرپرست‌های همان واحد را ببیند" },
  { key: "canCreateMeeting", label: "ثبت درخواست جلسه", hint: "" },
  { key: "canCreateMinute", label: "ثبت صورتجلسه", hint: "" },
  { key: "canExportExcel", label: "خروجی اکسل", hint: "" }
];

const roleOptions = Object.keys(ROLE_LABELS);

export function NewPositionForm() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [baseRole, setBaseRole] = useState("STAFF");
  const [flags, setFlags] = useState<Record<string, boolean>>({
    canManageOrgWide: false,
    canViewAllOrg: false,
    canViewUnitStaff: false,
    canCreateMeeting: true,
    canCreateMinute: true,
    canExportExcel: true
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/positions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, description, baseRole, ...flags })
      });
      const json = await res.json();
      if (!json.success) {
        setError(json.error ?? "خطا در ثبت سمت");
        return;
      }
      setTitle("");
      setDescription("");
      router.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان سمت (مثلا سرپرست فروش)" className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" required />
      <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="توضیح کوتاه (اختیاری)" rows={2} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm" />
      <div>
        <label className="block text-xs text-navy-500 mb-1.5">رتبه‌ی مبنا (برای رنگ/نمایش سازگاری با نسخه قبل)</label>
        <select value={baseRole} onChange={(e) => setBaseRole(e.target.value)} className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm">
          {roleOptions.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
        </select>
      </div>
      <div className="space-y-2 border border-navy-100 rounded-xl p-3">
        <p className="text-xs font-medium text-navy-600 mb-1">سطوح دسترسی این سمت</p>
        {permissionFields.map((f) => (
          <label key={f.key} className="flex items-start gap-2 text-sm text-navy-700">
            <input
              type="checkbox"
              className="mt-1"
              checked={flags[f.key]}
              onChange={(e) => setFlags((prev) => ({ ...prev, [f.key]: e.target.checked }))}
            />
            <span>
              {f.label}
              {f.hint && <span className="block text-[11px] text-navy-400">{f.hint}</span>}
            </span>
          </label>
        ))}
      </div>
      {error && <p className="text-sm text-status-danger">{error}</p>}
      <Button type="submit" disabled={loading}>{loading ? "در حال ثبت..." : "+ افزودن سمت"}</Button>
    </form>
  );
}
