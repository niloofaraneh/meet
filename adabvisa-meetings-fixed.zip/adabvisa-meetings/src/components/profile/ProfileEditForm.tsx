"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";

export function ProfileEditForm({
  userId,
  bio,
  avatarUrl,
  notifyByInApp,
  notifyBySms
}: {
  userId: string;
  bio: string;
  avatarUrl: string;
  notifyByInApp: boolean;
  notifyBySms: boolean;
}) {
  const router = useRouter();
  const [form, setForm] = useState({ bio, avatarUrl, notifyByInApp, notifyBySms });
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  async function save() {
    setLoading(true);
    try {
      await fetch(`/api/users/${userId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      router.refresh();
      setOpen(false);
    } finally {
      setLoading(false);
    }
  }

  if (!open) {
    return (
      <div>
        <Button variant="secondary" onClick={() => setOpen(true)}>ویرایش پروفایل و تنظیمات اعلان</Button>
      </div>
    );
  }

  return (
    <Card className="space-y-4">
      <div>
        <label className="block text-sm text-navy-700 mb-1.5">آدرس تصویر پروفایل (URL)</label>
        <input
          value={form.avatarUrl}
          onChange={(e) => setForm((f) => ({ ...f, avatarUrl: e.target.value }))}
          placeholder="https://..."
          dir="ltr"
          className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm"
        />
      </div>
      <div>
        <label className="block text-sm text-navy-700 mb-1.5">درباره من</label>
        <textarea
          value={form.bio}
          onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))}
          rows={3}
          className="w-full rounded-xl border border-navy-100 px-4 py-2.5 text-sm"
        />
      </div>
      <div className="flex flex-col gap-2">
        <label className="flex items-center gap-2 text-sm text-navy-600">
          <input type="checkbox" checked={form.notifyByInApp} onChange={(e) => setForm((f) => ({ ...f, notifyByInApp: e.target.checked }))} />
          دریافت اعلان داخل پنل
        </label>
        <label className="flex items-center gap-2 text-sm text-navy-600">
          <input type="checkbox" checked={form.notifyBySms} onChange={(e) => setForm((f) => ({ ...f, notifyBySms: e.target.checked }))} />
          دریافت اعلان پیامکی
        </label>
      </div>
      <div className="flex gap-2">
        <Button disabled={loading} onClick={save}>{loading ? "در حال ذخیره..." : "ذخیره"}</Button>
        <Button variant="ghost" onClick={() => setOpen(false)}>انصراف</Button>
      </div>
    </Card>
  );
}
