import { Role } from "@/lib/enums";
import "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      name: string;
      phone: string;
      role: Role;
      unitId: string | null;
      unitName: string | null;
      avatarUrl: string | null;
      positionTitle: string | null;
      canManageOrgWide: boolean;
      canViewAllOrg: boolean;
      canViewUnitStaff: boolean;
      canCreateMeeting: boolean;
      canCreateMinute: boolean;
      canExportExcel: boolean;
    };
  }
}

export type ApiResponse<T = unknown> = {
  success: boolean;
  data?: T;
  error?: string;
};
